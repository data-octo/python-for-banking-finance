# Copyright 2019 by Teradata Corporation. All rights reserved.

sVersionNumber = "16.20.0.8"
